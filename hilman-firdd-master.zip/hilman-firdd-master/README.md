<a href="https://twitter.com/hilmanfirdaus48">![badge:twitter](https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)</a>
<a href="https://www.linkedin.com/in/hilman-firdd">![badge:linkedin](https://img.shields.io/badge/LinkedIn-66666?style=for-the-badge&logo=linkedin&logoColor=white)</a>
<a href="https://portfolio-hilman-firdaus.vercel.app">![badge:resume](https://img.shields.io/badge/website-0077B5?style=for-the-badge&logo=About.me&logoColor=white)</a>
<a href="https://www.instagram.com/hilman_firdd">![badge:resume](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)</a>


# TL;DR <img src="https://cdn.joypixels.com/products/previews/O6D7BMG8R2DMMNC4LLZH/3084_vam5PaUBOZubnfnTPYC2Zfj4JaiicECV.gif" width="32" />
<!-- - 🔭 &nbsp; I’m currently looking for a new job in Front End role – preferably remote worldwide. -->
- 💼 &nbsp; I'm part of [Hilfi Developer] a Fullstack Developer.
- 🌱 &nbsp; I’m currently learning DevOps and Javascript Expert.
- 💬 &nbsp; I speak English 🏴󠁧󠁢󠁥󠁮󠁧󠁿 and Indonesian Language 🇮🇩.
- 📫 &nbsp; I can be reached at `hilmanfirdaus48@gmail.com`. See you in my gmail 👋

## My Stats <img src="http://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-12/256/man-technologist.png" width="28"/>
[![Hilman Firdd GitHub stats](https://github-readme-stats.vercel.app/api?username=hilman-firdd&show_icons=true&theme=radical)](https://github.com/hilman-firdd/github-readme-stats)

## My top-notch skills <img src="https://cdn.joypixels.com/products/previews/O6D7BMG8R2DMMNC4LLZH/3077_O2SFhOsxCkfgqyVoBHutvxuoKMEx9XmF.gif" width="28" />
| Field        | Skills                                                                               |
|:-------------|:-------------------------------------------------------------------------------------|
| Front End ✨  | `HTML` `CSS3` `(S)CSS` `ES6` `Vue` `Nuxt Js` `Bootstrap` `Tailwind`           |
| Back End ⚡️   | `PHP` `Laravel` `Express Js` `MySQL` `MongoDB` `REST API` `Firebase`                |
| UI Design 🎨  | `Figma` `Adobe Photoshop` `Adobe XD`                              |
| CMS 🎨        | `Wordpress`                                                      |
| Generalist 🛠 | `Git` `Docker` `VSCode` `NPM` `Webpack` `CI/CD`                |
| QA 🥸        | `Katalon`                                                      |

<!--END_SECTION:waka-->

<!-- repository because its `README.md` (this file) appears on your GitHub profile.
